package com.example.kafkaProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
